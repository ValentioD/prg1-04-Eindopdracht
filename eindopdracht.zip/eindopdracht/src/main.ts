import * as ex from 'excalibur'
import { loader } from './resources'
import { GameOverScene } from './scenes/gameover'
import Level1 from './scenes/level1'

const game = new ex.Engine({
  resolution: {
    width: 800,
    height: 600
  },
  displayMode: ex.DisplayMode.FitScreen,
  physics: {
    gravity: new ex.Vector(0, 1000),
    colliders: {
      compositeStrategy: 'separate'
    }
  }
})

game.add('game', new Level1())
game.add('gameover', new GameOverScene())

game.start(loader).then(() => {
  game.goToScene('game')
})
