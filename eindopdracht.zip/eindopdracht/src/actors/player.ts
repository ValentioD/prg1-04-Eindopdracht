import {
  Actor,
  Keys,
  Vector,
  Engine,
  CollisionType
} from 'excalibur'
import { Resources } from '../resources'

export class Player extends Actor {
  speed = 200
  jumpPower = -500
  canJump = false

  constructor() {
    super({
      width: 40,
      height: 40,
      collisionType: CollisionType.Active
    })
    this.anchor.setTo(0.5, 1)
  }

  onInitialize(engine: Engine): void {
    this.graphics.use(Resources.PlayerSprite.toSprite())

    this.on('preupdate', () => {
      const input = engine.input.keyboard

      if (input.isHeld(Keys.Left)) {
        this.vel.x = -this.speed
      } else if (input.isHeld(Keys.Right)) {
        this.vel.x = this.speed
      } else {
        this.vel.x = 0
      }

      if ((input.wasPressed(Keys.Up) || input.wasPressed(Keys.Space)) && this.canJump) {
        this.vel.y = this.jumpPower
        this.canJump = false
      }

      if (this.pos.y > engine.drawHeight + 100) {
        engine.goToScene('gameover')
      }
    })

    this.on('postcollision', (evt) => {
      const other = evt.other.owner
      if (
        other instanceof Actor &&
        other.collisionType === CollisionType.Fixed &&
        this.vel.y >= 0 &&
        this.pos.y <= other.pos.y
      ) {
        this.canJump = true
      }
    })
  }
}
