import {
  Scene,
  Engine,
  Label,
  Color,
  Font,
  FontUnit,
  Vector,
  Keys
} from 'excalibur'
import { GameScene } from './gamescene' // Zorg dat GameScene correct geëxporteerd is

export class GameOverScene extends Scene {
  onInitialize(engine: Engine): void {
    this.engine.backgroundColor = Color.Black

    const gameOverLabel = new Label({
      text: 'Game Over\nDruk op R om opnieuw te starten',
      pos: new Vector(400, 300),
      color: Color.Red,
      font: new Font({
        size: 40,
        unit: FontUnit.Px,
        family: 'Arial',
        bold: true
      }),
      anchor: new Vector(0.5, 0.5)
    })

    this.add(gameOverLabel)

    this.on('preupdate', () => {
      if (engine.input.keyboard.wasPressed(Keys.R)) {
        // Verwijder oude game scene
        engine.removeScene('game')

        // Voeg een nieuwe versie van de game scene toe
        engine.add('game', new GameScene())

        // Reset Game Over status
        ;(engine as any).hasTriggeredGameOver = false

        // Ga naar de nieuwe game scene
        engine.goToScene('game')
      }
    })
  }
}
