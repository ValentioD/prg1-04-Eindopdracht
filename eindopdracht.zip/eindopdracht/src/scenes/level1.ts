import { Scene, Engine, Vector, Actor } from 'excalibur'
import { Player } from '../actors/player'
import { Platform } from '../actors/platform'
import { Resources } from '../resources'
import { setupCamera } from '../utils/camera'

export default class Level1 extends Scene {
  private player: Player

  onInitialize(engine: Engine): void {
    const bgSprite = Resources.Background.toSprite()
    const bg = new Actor({
      pos: new Vector(0, 0),
      z: -1,
      anchor: Vector.Zero
    })
    bg.graphics.use(bgSprite)
    bg.graphics.current.scale = new Vector(2, 2)
    engine.add(bg)

    this.player = new Player()
    this.player.pos = new Vector(100, 300)
    engine.add(this.player)

    setupCamera(engine, this.player)

    const ground = new Platform(0, 580, 2000, 40)
    engine.add(ground)

    const platforms = [
      new Platform(800, 520, 100, 20),
      new Platform(1000, 470, 100, 20),
      new Platform(1200, 420, 100, 20),
      new Platform(1400, 370, 100, 20),
      new Platform(1600, 320, 100, 20),
      new Platform(1800, 270, 100, 20),
      new Platform(2000, 220, 100, 20),
      new Platform(2200, 170, 100, 20),
      new Platform(2400, 120, 100, 20)
    ]

    for (const p of platforms) {
      engine.add(p)
    }
  }
}
